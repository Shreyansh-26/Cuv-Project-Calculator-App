let displayValue = "0";
let shouldResetDisplay = false;  // This flag helps in resetting display after new number entry

function updateDisplay() {
  document.getElementById("display").innerText = displayValue;
}

function appendNumber(number) {
  if (shouldResetDisplay) {  // Resets the display if needed (after '=')
    displayValue = number;
    shouldResetDisplay = false;  // Clear the flag after first input
  } else {
    if (displayValue === "0") {
      displayValue = number;
    } else {
      displayValue += number;
    }
  }
  updateDisplay();
}

function appendOperator(operator) {
  if (shouldResetDisplay) {  // If an operator is entered after calculation, continue with the result
    shouldResetDisplay = false;
  }
  displayValue += " " + operator + " ";
  updateDisplay();
}

function deleteLast() {
  displayValue = displayValue.trim().slice(0, -1) || "0";
  updateDisplay();
}

function resetCalc() {
  displayValue = "0";
  shouldResetDisplay = false;  // Reset the flag when the calculation is cleared
  updateDisplay();
}

function calculate() {
  try {
    displayValue = eval(displayValue.replace(/x/g, "*")).toString();
    shouldResetDisplay = true;  // Set flag to allow new operations after calculation
  } catch (error) {
    displayValue = "Error";
  }
  updateDisplay();
}
